create function st_disjoint(rast1 raster, rast2 raster) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$ SELECT public.ST_Disjoint($1, NULL::integer, $2, NULL::integer) $$;

comment on function st_disjoint(raster, raster) is 'args: rastA, rastB - Return true if raster rastA does not spatially intersect rastB.';

alter function st_disjoint(raster, raster) owner to postgres;

