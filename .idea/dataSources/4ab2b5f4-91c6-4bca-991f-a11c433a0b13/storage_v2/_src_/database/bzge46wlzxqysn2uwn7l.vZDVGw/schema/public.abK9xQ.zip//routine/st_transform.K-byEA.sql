create function st_transform(rast raster, srid integer, scalexy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public._ST_gdalwarp($1, $4, $5, $2, $3, $3) $$;

alter function st_transform(raster, integer, double precision, text, double precision) owner to postgres;

