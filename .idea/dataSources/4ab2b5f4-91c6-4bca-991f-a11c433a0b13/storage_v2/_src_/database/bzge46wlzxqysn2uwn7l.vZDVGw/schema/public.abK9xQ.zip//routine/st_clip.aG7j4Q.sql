create function st_clip(rast raster, nband integer, geom geometry, crop boolean) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_Clip($1, ARRAY[$2]::integer[], $3, null::double precision[], $4) $$;

comment on function st_clip(raster, integer, geometry, boolean) is 'args: rast, nband, geom, crop - Returns the raster clipped by the input geometry. If band number not is specified, all bands are processed. If crop is not specified or TRUE, the output raster is cropped.';

alter function st_clip(raster, integer, geometry, boolean) owner to postgres;

