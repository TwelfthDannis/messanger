create function st_stddev4ma(value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[]) returns double precision
    immutable
    parallel safe
    language sql
as
$$ SELECT stddev(unnest) FROM unnest($1) $$;

comment on function st_stddev4ma(double precision[], integer[], text[]) is 'args: value, pos, VARIADIC userargs - Raster processing function that calculates the standard deviation of pixel values in a neighborhood.';

alter function st_stddev4ma(double precision[], integer[], text[]) owner to postgres;

