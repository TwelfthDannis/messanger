create function postgis_raster_scripts_installed() returns text
    immutable
    parallel safe
    language sql
as
$$ SELECT trim('3.3.3'::text || $rev$ 2355e8e $rev$) AS version $$;

alter function postgis_raster_scripts_installed() owner to postgres;

