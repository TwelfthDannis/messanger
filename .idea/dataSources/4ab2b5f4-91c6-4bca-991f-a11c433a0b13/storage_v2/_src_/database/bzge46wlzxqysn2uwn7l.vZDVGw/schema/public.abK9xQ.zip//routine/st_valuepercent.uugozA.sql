create function st_valuepercent(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, searchvalues double precision[] DEFAULT NULL::double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) returns SETOF record
    immutable
    parallel safe
    language sql
as
$$ SELECT value, percent FROM public._ST_valuecount($1, $2, $3, $4, $5) $$;

alter function st_valuepercent(raster, integer, boolean, double precision[], double precision, out double precision, out double precision) owner to postgres;

