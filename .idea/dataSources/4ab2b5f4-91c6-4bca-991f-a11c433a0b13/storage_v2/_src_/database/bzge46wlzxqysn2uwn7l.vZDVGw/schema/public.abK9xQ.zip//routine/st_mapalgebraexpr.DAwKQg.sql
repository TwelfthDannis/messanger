create function st_mapalgebraexpr(rast raster, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_mapalgebraexpr($1, 1, $2, $3, $4) $$;

comment on function st_mapalgebraexpr(raster, text, text, double precision) is 'args: rast, pixeltype, expression, nodataval=NULL - 1 raster band version: Creates a new one band raster formed by applying a valid PostgreSQL algebraic operation on the input raster band and of pixeltype provided. Band 1 is assumed if no band is specified.';

alter function st_mapalgebraexpr(raster, text, text, double precision) owner to postgres;

